<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct gender_id2,g_name FROM data10,gender where gender_id1 = $id and gen_index_id = $pid and gender.id = data10.gender_id2";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Φύλο</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gender_id2"]; ?>"><?php echo $nationality["g_name"] ?></option>
	<?php		
		
		
	}
}

?>