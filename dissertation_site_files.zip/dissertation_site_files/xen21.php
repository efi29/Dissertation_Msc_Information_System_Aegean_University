<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct year_id,year_number FROM data7,year where data7.gen_index_id = $id and data7.middle_id = $pid and year.id = data7.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	$i=1;
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		$i = $i + 1;
		
	}
}

?>