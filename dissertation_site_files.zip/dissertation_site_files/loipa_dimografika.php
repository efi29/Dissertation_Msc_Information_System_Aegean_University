<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΛΟΙΠΩΝ ΔΗΜΟΓΡΑΦΙΚΩΝ ΣΤΟΙΧΕΙΩΝ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide_loipa_dimografika.js"></script> 
 
   <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 </head>
 <body>
<ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li  ><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li ><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li class="current"><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>

</ul>>
 <h3>ΔΕΙΚΤΕΣ ΛΟΙΠΩΝ ΔΗΜΟΓΡΑΦΙΚΩΝ ΣΤΟΙΧΕΙΩΝ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">

<div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE id = 13";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
</div>
<br/><br/>

<div class="select">
<select name="gen_index" id="gen_index" onchange="d24(this.value);d22(this.value);d20(this.value);d18(this.value);d16(this.value);d14(this.value);d10(this.value);d12(this.value);d1(this.value);d4(this.value);d7(this.value);d8(this.value);d9(this.value);">
<option value="">Διάλεξε Γενικό δείκτη</option>
  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 13 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>
</div>
<br/><br/>

<div id="choice_1" class="select">
	<select name="gender_a1" id="gender_a1" onchange="d2(this.value);">
	<option value="">Διάλεξε Φύλο ατόμων</option>
  <select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d1(val)
{
	$.ajax({
	type: "POST", 
	url:"d1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#gender_a1").html(data);
	}
});
}
</script>
<br/><br/>
	
	
	
	
	
	<select name="gender_a2" id="gender_a2" onchange="d3(this.value);">
	<option value="">Διάλεξε Φύλο συνολικού πληθυσμού</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#gender_a2").html(data);
	}
});
}
</script>

<br/><br/>
	<select name="year_1" id="year_1">
	<option value="">Διάλεξε Έτος </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d3(val)
{
	var val3 = $("#gender_a1 option:selected").val();
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d3.php",
	data:{'id': val, 'pid':val2, 'g':val3},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_2" class="select">
	<select name="gender_b1" id="gender_b1"; onchange="d5(this.value);">
	<option value="">Διάλεξε Φύλο Ελλήνων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d4(val)
{
	$.ajax({
	type: "POST", 
	url:"d1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#gender_b1").html(data);
	}
});
}
</script>



<br/><br/>
	<select name="gender_b2" id="gender_b2" onclick="d6(this.value);">
	<option value="">Διάλεξε Φύλο συνολικού πληθυσμού</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d5(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#gender_b2").html(data);
	}
});
}
</script>
<br/><br/>
	<select name="year_2" id="year_2">
	<option value="">Διάλεξε Έτος </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d6(val)
{
	var val3 = $("#gender_b1 option:selected").val();
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d3.php",
	data:{'id': val, 'pid':val2, 'g':val3},
	success: function(data)
	{
			$("#year_2").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_3" class = "select">
	
	<select name="year_3" id="year_3">
	<option value="">Διάλεξε Έτος </option>

</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d7(val)
{
	$.ajax({
	type: "POST", 
	url:"d7.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_3").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_4" class="select">
	<select name="year_4" id="year_4">
	<option value="">Διάλεξε Έτος </option>
</select>

<br/><br/>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d8(val)
{
	$.ajax({
	type: "POST", 
	url:"d7.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_4").html(data);
	}
});
}
</script>
</div>

<div id="choice_5" class="select">
	<select name="nationality_5" id="nationality_5" onchange="d11(this.value)";>
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
<br/><br/>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d10(val)
{
	$.ajax({
	type: "POST", 
	url:"d10.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_5").html(data);
	}
});
}
</script>
	<select name="year_5" id="year_5">
	<option value="">Διάλεξε Έτος Μεταβολής </option>
</select>
<br/><br/>
</div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d11(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d11.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_5").html(data);
	}
});
}
</script>


<div id="choice_6" class="select">
	<select name="age_met_6" id="age_met_6" onchange="d13(this.value);">
	<option value="">Διάλεξε Ηλικιακή Ομάδα</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d12(val)
{
	$.ajax({
	type: "POST", 
	url:"d12.php",
	data:"id="+val,
	success: function(data)
	{
			$("#age_met_6").html(data);
	}
});
}
</script>



<br/><br/>
	<select name="year_6" id="year_6">
	<option value="">Διάλεξε Έτος  </option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d13(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d13.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_6").html(data);
	}
});
}
</script>

<br/><br/>
</div>

<div id="choice_7" class="select">
	<select name="age_met_7" id="age_met_7" onchange="d15(this.value);">
	<option value="">Διάλεξε Ηλικιακή Ομάδα</option>
	</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d14(val)
{
	$.ajax({
	type: "POST", 
	url:"d12.php",
	data:"id="+val,
	success: function(data)
	{
			$("#age_met_7").html(data);
	}
});
}
</script>
	
<br/><br/>
	<select name="year_7" id="year_7">
	<option value="">Διάλεξε Έτος  </option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d15(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d13.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_7").html(data);
	}
});
}
</script>

<br/><br/>
</div>

<div id="choice_8" class="select">
	<select name="nationality_8" id="nationality_8" onchange="d17(this.value);">
	<option value="">Διάλεξε εθνικότητα</option>

	</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d16(val)
{
	$.ajax({
	type: "POST", 
	url:"d10.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_8").html(data);
	}
});
}
</script>
	
	
<br/><br/>
	<select name="year_8" id="year_8">
	<option value="">Διάλεξε Έτος  </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d17(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d11.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_8").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_9" class="select">
	<select name="nationality_9" id="nationality_9" onchange="d19(this.value);">
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
		<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d18(val)
{
	$.ajax({
	type: "POST", 
	url:"d10.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_9").html(data);
	}
});
}
</script>
	
	
	
<br/><br/>

	<select name="year_9" id="year_9">
	<option value="">Διάλεξε Έτος  </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d19(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d11.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_9").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_10" class="select">
	<select name="nationality_10" id="nationality_10" onchange="d21(this.value);">
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
  <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d20(val)
{
	$.ajax({
	type: "POST", 
	url:"d10.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_10").html(data);
	}
});
}
</script>
<br/><br/>
	<select name="year_10" id="year_10">
	<option value="">Διάλεξε Έτος  </option>
	</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d21(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d11.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_10").html(data);
	}
});
}
</script>

<br/><br/>
</div>

<div id="choice_11" class="select">
	<select name="nationality_11" id="nationality_11" onchange="d23(this.value);">
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d22(val)
{
	$.ajax({
	type: "POST", 
	url:"d10.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_11").html(data);
	}
});
}
</script>
	
	
<br/><br/>

	<select name="year_11" id="year_11">
	<option value="">Διάλεξε Έτος  </option>
</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d23(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"d11.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_11").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_12" class="select">
	<select name="year_12" id="year_12">
	<option value="">Διάλεξε Έτος  </option>
 
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function d24(val)
{
	$.ajax({
	type: "POST", 
	url:"d7.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_12").html(data);
	}
});
}
</script>
<br/><br/>
</div>


<br/><br/>


<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>

<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";

	$gender_a1 = "";
	$gender_a2 = "";
	$year_1= "";
	
	
	$gender_b1 = "";
	$gender_b2 = "";
	$year_2= "";
	
	$year_3= "";
	

	$year_4= "";
	
	
	$nationality_5 = "";
	$year_5= "";
	
	$age_met_6 = "";
	$year_6= "";
	
	$age_met_7 = "";
	$year_7= "";
	
	$nationality_8 = "";
	$year_8= "";
	
	$nationality_9 = "";
	$year_9= "";

	$nationality_10 = "";
	$year_10= "";
	
	$nationality_11 = "";
	$year_11= "";
	
	
	$year_12= "";
	


if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];

	
	$gender_a1 = $_POST['gender_a1'];
	$gender_a2 = $_POST['gender_a2'];
	$year_1= $_POST['year_1'];
	
	
	$gender_b1 = $_POST['gender_b1'];
	$gender_b2 = $_POST['gender_b2'];
	$year_2= $_POST['year_2'];
	
	$year_3= $_POST['year_3'];
	
	
	$year_4= $_POST['year_4'];
	
	$nationality_5 = $_POST['nationality_5'];
	$year_5= $_POST['year_5'];
	
	$age_met_6  = $_POST['age_met_6'];
	$year_6= $_POST['year_6'];
	
	$age_met_7 = $_POST['age_met_7'];
	$year_7= $_POST['year_7'];
	
	$nationality_8 = $_POST['nationality_8'];
	$year_8= $_POST['year_8'];
	
	$nationality_9 = $_POST['nationality_9'];
	$year_9= $_POST['year_9'];
	
	$nationality_10 = $_POST['nationality_10'];
	$year_10= $_POST['year_10'];
	
	$nationality_11 = $_POST['nationality_11'];
	$year_11= $_POST['year_11'];
	
	$year_12= $_POST['year_12'];
	
	if ((empty($category) || empty($gen_index)    || empty($gender_a1) || empty($gender_a2) || empty($year_1) ) && (empty($category) || empty($gen_index)    || empty($gender_b1) || empty($gender_b2) || empty($year_2) ) && (empty($category) || empty($gen_index)|| empty($year_3) ) && (empty($category) || empty($gen_index) || empty($year_4) ) && (empty($category) || empty($gen_index) || empty($nationality_5) || empty($year_5)) && (empty($category) || empty($gen_index) || empty($age_met_6) || empty($year_6)) && (empty($category) || empty($gen_index) || empty($age_met_7) || empty($year_7)) && (empty($category) || empty($gen_index) || empty($nationality_8) || empty($year_8)) && (empty($category) || empty($gen_index) || empty($nationality_9) || empty($year_9))&& (empty($category) || empty($gen_index) || empty($nationality_10) || empty($year_10))&& (empty($category) || empty($gen_index) || empty($nationality_11) || empty($year_11)) && (empty($category) || empty($gen_index) || empty($year_12)))
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{

	if ($gen_index == 97 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.gender_id1 = $gender_a1 and data10.gender_id2 = $gender_a2 and data10.year_id = $year_1";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.gender_id1 = $gender_a1 and data10.gender_id2 = $gender_a2 ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if ($gen_index == 98 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.gender_id1 = $gender_b1 and data10.gender_id2 = $gender_b2 and data10.year_id = $year_2";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.gender_id1 = $gender_b1 and data10.gender_id2 = $gender_b2 ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 99)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.year_id = $year_3";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 100)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.year_id = $year_4";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 101 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.nat_id = $nationality_5 and data10.year_id = $year_5";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.nat_id = $nationality_5  ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 102 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.age_met_id = $age_met_6 and data10.year_id = $year_6";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.age_met_id = $age_met_6  ";
		$result1 = mysqli_query($db, $query1);
	
	}
	
	else if($gen_index == 103 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.age_met_id = $age_met_7 and data10.year_id = $year_7";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.age_met_id = $age_met_7  ";
		$result1 = mysqli_query($db, $query1);
	
	}
	
	else if($gen_index == 104 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.nat_id = $nationality_8 and data10.year_id = $year_8";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.nat_id = $nationality_8  ";
		$result1 = mysqli_query($db, $query1);
	
	}
	
	else  if($gen_index == 105)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.nat_id = $nationality_9 and data10.year_id = $year_9";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.nat_id = $nationality_9  ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else  if($gen_index == 106)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.nat_id = $nationality_10 and data10.year_id = $year_10";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.nat_id = $nationality_10  ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else  if($gen_index == 107)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.nat_id = $nationality_11 and data10.year_id = $year_11";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index and data10.nat_id = $nationality_11  ";
		$result1 = mysqli_query($db, $query1);
	}
	
	else  if($gen_index == (108 OR 109))
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index  and data10.year_id = $year_12";
		$query1 = "SELECT  year.year_number  as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data10, spec_index, year WHERE data10.year_id = year.id and data10.spec_index_id = spec_index.id   and data10.cat_id = $category and data10.gen_index_id = $gen_index   ";
		$result1 = mysqli_query($db, $query1);
	}
	
	
		$result = mysqli_query($db, $query);
		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
	


	

	
echo "</table>";

	$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format

$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);

//echo $jsonTable; 
}
}	
mysqli_close($db);	

?>

<!--Load the Ajax API-->

<br>
     <input type='button' class="button button1" value="Column Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
     <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το έτος',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
    }
    </script>
 

 </div>

<p><?php echo $error_message; ?></p>
 <!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="display:none"></div>
	<div id="chart2div" style="display:none"></div>

</div>


</body>
</html>