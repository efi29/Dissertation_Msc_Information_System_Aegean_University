<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$g = $_POST["g"];
	$query = "SELECT distinct year_id,year_number FROM data10,year where gender_id1 = $g and gender_id2 = $id and gen_index_id = $pid and year.id = data10.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>