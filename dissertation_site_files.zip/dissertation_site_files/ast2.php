<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct year_id,year_number FROM data14,year where gen_index_id = $pid and nat_id = $id and year.id = data14.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	$i=1;
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		$i = $i + 1;
		
	}
}

?>