<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct year_id,year_number  FROM data10,year where gen_index_id = $id and year.id = data10.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>