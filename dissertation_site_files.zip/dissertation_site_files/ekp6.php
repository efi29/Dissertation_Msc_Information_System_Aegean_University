<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$nat1 = $_POST["nat1"];
	$nat2 = $_POST["nat2"];
	$vath = $_POST["vath"];
	$apok = $_POST["apok"];
	$query = "SELECT distinct year_id,year_number FROM data12,year where nat_id2 = $nat2 and apok_dioikisi_id = $apok and gen_index_id = $pid and vathmida_ekpaideysis_id = $vath and nat_id1 = $nat1 and perifereia_id = $id and year.id = data12.year_id";
	$result = mysqli_query($db, $query); 

	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>