<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$g = $_POST["g"];
	$g1 = $_POST["g1"];
	$id = $_POST["id"];
	$query = "SELECT distinct year_id,year_number FROM data3,year where gen_index_id = $id and gender_id1 = $g and gender_id2 = $g1 and year.id = data3.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>