<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct nat_id,nat_name  FROM data13,nationality where gen_index_id = $id and nationality.id = data13.nat_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε εθνικότητα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>