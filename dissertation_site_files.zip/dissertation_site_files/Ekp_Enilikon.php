<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>

<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
 <style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 
 <title>ΔΕΙΚΤΕΣ ΕΚΠΑΙΔΕΥΣΗΣ ΕΝΗΛΙΚΩΝ</title>
 </head>
 <body>
 <ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li class="current"><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>


 <h3>ΔΕΙΚΤΕΣ ΕΚΠΑΙΔΕΥΣΗΣ ΕΝΗΛΙΚΩΝ</h3>
 
 
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 
 
 
 <form action="?" method="post">
 <div>
 
 <!--φτιάχνουμε μια συνάρτηση αν έχουμε onchange στο drop down list, περνουμε τη selected value της λίστας-->
  <div class="select">

 <select name="category"  onchange="getId(this.value);"><!--η drop down list έχει values τη στηλη id-->
 <!--populate drop down list από τον πίνακα category με την php-->
 <option value="" disabled selected>Διάλεξε κατηγορία*</option>
 </div>
  <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 1";//στέλνει την εντολή αναζήτησης στη βάση
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
		<div class="select__arrow"></div>
</div>
</div>
<br>
<br>

  <div class="select">
<select name="gen_index" id="gen_index"><!--δίνουμε id στο 2ο drop down:gen_index-->
<option value="">Διάλεξε Γενικό Δείκτη</option>
</select>
		<div class="select__arrow"></div>

</div>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getId(val)//, οποτε περναμε τη value στο ajax
{
//we create ajax function
	$.ajax({
	type: "POST",
	//getdata7.php είναι το αρχείο όπου κάνουμε το query για το δεύτερο drop down 
	url:"getdata7.php",
	data:"id="+val,
	success: function(data)//εκτέλεση της functions, αν success
	{
			$("#gen_index").html(data);
	}
	
	
	
});
	
	
}


</script>
<br>
<br>
  <div class="select">
 <select name="gender">
 <option value="">Διάλεξε φύλο</option>
  
 <?php
	
	$query = "SELECT * FROM gender";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gender)
	{
		?>
		<option value="<?php echo $gender["id"]; ?>"><?php echo $gender["g_name"] ?></option>
	<?php	 
	}
?>
</select>
		<div class="select__arrow"></div>

</div>
<br>
<br>

  <div class="select">
 <select name="nationality">
 <option value="">Διάλεξε εθνικότητα</option>
  
 <?php
	
	$query = "SELECT * FROM nationality WHERE id IN(1,2,3,4)";
	$result = mysqli_query($db, $query);
	
	foreach($result as $nationality)
	{
		?>
		<option value="<?php echo $nationality["id"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php	 
	}
?>
</select>
		<div class="select__arrow"></div>

</div>
<br>
<br>
<div class="select">
 <select name="year">
 <option value="">Διάλεξε Έτος</option>
  
  <?php 	
	 $query = "SELECT * FROM year WHERE id=1";
	 $result = mysqli_query($db, $query);
	
	 foreach($result as $year)
	 {
		 ?>
		 <option value="<?php echo $year["id"]; ?>"><?php echo $year["year_number"] ?></option>
	 <?php	 
	 }
 ?>
</select>
		<div class="select__arrow"></div>

</div>
<br><br/>
<input type="submit" name="submit" id="submit" value="Υποβολή" >

</form>
</div>



<div>

<?php
$error_message = "";
$category= "";
$category = "";
$gen_index = "";
$gender = "";
$nationality = "";
$result2 = "";
$year = "";

if (isset($_POST["submit"])){	


	 //ορίζουμε μεταβλητές για κάθε drop down list
	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];
	$gender = $_POST['gender'];
	$nationality = 	$_POST['nationality'];
	$year = $_POST['year'];
	
	if ((empty($category) || empty($gen_index)  || empty($gender)  || empty($nationality) || empty($year) ) )
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{
	//τρέχουμε το ερώτημα στη βάση για να εμφανίσουμε την ονομασία του ειδικού δείκτη και τον υπολογισμό του δείκτη
	//όπου στους πίνακες data και spec_index, 
	$query1 = "SELECT  year.year_number as Year, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data, spec_index, year WHERE data.year_id = year.id and  data.spec_index_id = spec_index.id and data.cat_id = $category and data.gen_index_id = $gen_index and data.g_id=$gender and data.nat_id = $nationality";	
	$result1 = mysqli_query($db, $query1);
	$query2 = "SELECT  year.year_number as Year, nationality.nat_name as Εθνικότητα, calc as Τιμή_Δείκτη FROM  data, nationality, year WHERE data.year_id = year.id and  data.nat_id = nationality.id and data.cat_id = $category and data.gen_index_id = $gen_index and data.g_id=$gender";	
	$result2 = mysqli_query($db, $query2);
	if($result1 === FALSE  ) { 
    die(mysql_error()); // TODO: better error handling
	}
	
	echo "<table border='1' >
		<tr>
		<th >Έτος</th>
		<th>Όνομα Δείκτη</th>
		<th>Τιμή Δείκτη</th>
		</tr>";

	while($row = mysqli_fetch_row($result1))
	{
			
			echo "<tr>";
			echo "<td>".$row[0]."</td>";
			echo "<td>".$row[1]."</td>";
			echo "<td>".$row[2]."</td>";
			echo "</tr>";
	
	}
	
	

	
echo "</table><br>";

$jsonTable = "";
  $rows = array();
  $table = array();
  $table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Εθνικότητα', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result2) {
    foreach($result2 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (string) $r['Εθνικότητα']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format
$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
}
}
//echo $jsonTable;
mysqli_close($db);
 ?>
 
 <!--Load the Ajax API-->
 <br/>
	<input type='button' class="button button1" value="Bar Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
    <input type='button' class="button button1" value="Pie Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με την εθνικότητα',
          is3D: 'true',
          width: 1200,
          height: 800
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	   var chart = new google.visualization.PieChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
    }
    </script>
 

 </div>
<p><?php echo $error_message; ?></p>
 
 <!--this is the div that will hold the pie chart-->
     <div id="chart_div" style="width: 1200px; height: 800px; display:none"></div>
	<div id="chart2div"  style="width: 900px; height: 500px; display:none"></div>

 </body>
 </html>