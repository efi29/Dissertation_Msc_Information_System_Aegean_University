<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$id2 = $_POST["id2"];
	$query = "SELECT distinct nat_id2,nat_name FROM data2,nationality where gen_index_id = $id2 and nat_id1 = $id and data2.nat_id2 = nationality.id";
	$result = mysqli_query($db, $query);
	?> 
	
	<option value="">Διάλεξε Εθνικότητα Συνόλου Εργαζομένων</option>
	
	<?php
	foreach($result as $data2)
	{
	?>
		
		<option value="<?php echo $data2["nat_id2"]; ?>"><?php echo $data2["nat_name"] ?></option>
	<?php		
		
		
	}
}
?>