<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct nat_id1,nat_name  FROM data11,nationality where gen_index_id = $id and nationality.id = data11.nat_id1";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε εθνικότητα ανέργων</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id1"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>