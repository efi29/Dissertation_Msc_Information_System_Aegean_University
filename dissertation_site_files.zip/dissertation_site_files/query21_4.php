<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$g = $_POST["g"];
	$g1 = $_POST["g1"];
	$year = $_POST["year"];
	$query = "SELECT distinct tcn_country_prosfyges_id, tcn_country_name_prosfyges FROM data3,tcn_country_prosfyges where gender_id1 = $g and gender_id2 = $g1 and year_id = $year and gen_index_id = $id and tcn_country_prosfyges.id = data3.tcn_country_prosfyges_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Χώρα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["tcn_country_prosfyges_id"]; ?>"><?php echo $nationality["tcn_country_name_prosfyges"] ?></option>
	<?php		
		
		
	}
}

?>