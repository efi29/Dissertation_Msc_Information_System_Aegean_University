<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct gender_id,g_name  FROM data5,gender where gen_index_id = $id and gender.id = data5.gender_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Φύλο(Γαμπρός/Νύφη)</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gender_id"]; ?>"><?php echo $nationality["g_name"] ?></option>
	<?php		
		
		
	}
}

?>