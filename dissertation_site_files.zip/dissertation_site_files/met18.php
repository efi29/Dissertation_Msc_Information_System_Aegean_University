<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct tcn_country_met_id,tcn_country_name_met  FROM data9,tcn_country_met where gen_index_id = $pid and year_id = $id and data9.tcn_country_met_id = tcn_country_met.id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Υπηκοότητα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["tcn_country_met_id"]; ?>"><?php echo $nationality["tcn_country_name_met"] ?></option>
	<?php		
		
		
	}
}

?>