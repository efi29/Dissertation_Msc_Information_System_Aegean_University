<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct nat_id,nat_name FROM data17,nationality where gen_index_id = $pid and gender_id = $id and nationality.id = data17.nat_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε εθνικότητα</option>

	
	<?php
	$i=1;
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		$i = $i + 1;
		
	}
}

?>