<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$nat2 = $_POST["id"];
	$pid = $_POST["pid"];
	$nat1 = $_POST["nat1"];
	$query = "SELECT distinct nat_id2,nat_name FROM data12,nationality where gen_index_id = $pid and vathmida_ekpaideysis_id = $nat1 and nat_id1 = $nat2 and nationality.id = data12.nat_id2";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Υπηκοότητα μαθητών</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id2"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>