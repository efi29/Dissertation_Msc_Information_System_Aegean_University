/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
	
	if ($("#gen_index").val() == 30)
		
	{
		
		$("#choice_1").show()  ;
		
	}
        
    else
	{
		$("#choice_1").hide();
	}
        
	
	if ($("#gen_index").val() == 31)
	{
		$("#choice_2").show()  ;
	}
        
    else
	{
		$("#choice_2").hide();
	}
        
	

		
}



