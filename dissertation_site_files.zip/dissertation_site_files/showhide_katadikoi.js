/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
	
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
	if ($("#gen_index").val() == 190 )  
	{	
		$("#choice_1").show()  ;	
	}
	
	else
	{
		$("#choice_1").hide()  ;		
	}
	
	if ($("#gen_index").val() == 191 )  
	{	
		$("#choice_2").show()  ;	
	}
	
	else
	{
		$("#choice_2").hide()  ;		
	}
		
	if ($("#gen_index").val() == 192 || ($("#gen_index").val() == 193)  || ($("#gen_index").val() == 194) || ($("#gen_index").val() == 195) || ($("#gen_index").val() == 196) || ($("#gen_index").val() == 197) || ($("#gen_index").val() == 198) || ($("#gen_index").val() == 199) || ($("#gen_index").val() == 200))
		
	{
		$("#choice_3").show()  ;	
	}
        
    else
	{
		$("#choice_3").hide()  ;
		
	}
	
	if (($("#gen_index").val() == 201) || ($("#gen_index").val() == 202) || ($("#gen_index").val() == 203) || ($("#gen_index").val() == 204) || ($("#gen_index").val() == 205) || ($("#gen_index").val() == 206) || ($("#gen_index").val() == 207) || ($("#gen_index").val() == 208) || ($("#gen_index").val() == 209) || ($("#gen_index").val() == 210) || ($("#gen_index").val() == 211) || ($("#gen_index").val() == 212) || ($("#gen_index").val() == 213) || ($("#gen_index").val() == 214) || ($("#gen_index").val() == 215) || ($("#gen_index").val() == 216) || ($("#gen_index").val() == 217) || ($("#gen_index").val() == 218) || ($("#gen_index").val() == 219) || ($("#gen_index").val() == 220) || ($("#gen_index").val() == 221) || ($("#gen_index").val() == 222) || ($("#gen_index").val() == 223) || ($("#gen_index").val() == 224) || ($("#gen_index").val() == 225) || ($("#gen_index").val() == 226)) 
	
	{
		
		
		$("#choice_4").show()  ;
	
		
	}
        
    else
	{
		
		$("#choice_4").hide()  ;
	
	}
        
	
	
	
}



