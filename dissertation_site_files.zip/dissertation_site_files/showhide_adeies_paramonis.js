/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
	
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
		
	if ($("#gen_index").val() == 172 || ($("#gen_index").val() == 173)  || ($("#gen_index").val() == 174))  
	{	
		$("#choice_1").show()  ;	
	}
        
    else
	{
		$("#choice_1").hide()  ;		
	}
	
	if ($("#gen_index").val() == 175 || ($("#gen_index").val() == 176) || ($("#gen_index").val() == 177) || ($("#gen_index").val() == 178) || ($("#gen_index").val() == 179) || ($("#gen_index").val() == 180) || ($("#gen_index").val() == 181) || ($("#gen_index").val() == 182) || ($("#gen_index").val() == 183) || ($("#gen_index").val() == 184) || ($("#gen_index").val() == 185) || ($("#gen_index").val() == 186) || ($("#gen_index").val() == 187) || ($("#gen_index").val() == 188) || ($("#gen_index").val() == 189)) 
	
	{		
		$("#choice_2").show()  ;	
	}
        
    else
	{	
		$("#choice_2").hide()  ;
	}
       
}



