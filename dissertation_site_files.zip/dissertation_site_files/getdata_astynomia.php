<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	//τρεχουμε το ερωτημα : όπου βρουμε category_id στον πίνακα gen_index για να εμφανισουμε index_name
	$query = "SELECT * FROM gen_index WHERE category_id = $id ";
	$result = mysqli_query($db, $query);?>
	
	<option value="">Διάλεξε Γενικό Δείκτη</option>
	
	<?php
	foreach($result as $gen_index)
	{
	?>
		
		<option value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php		
		
		
	}
}

?>