<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct gen_index_id,index_name FROM data7,gen_index where data7.middle_id = $id and gen_index.id = data7.gen_index_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Γενικό δείκτη</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gen_index_id"]; ?>"><?php echo $nationality["index_name"] ?></option>
	<?php		
		
		
	}
}

?>