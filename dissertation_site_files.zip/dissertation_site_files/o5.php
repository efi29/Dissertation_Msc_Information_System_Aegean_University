<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$perif = $_POST["id"];
	$pid = $_POST["pid"];
	$nat1 = $_POST["nat1"];
	$nat2 = $_POST["nat2"];
	$apok = $_POST["apok"];
	$query = "SELECT distinct year_id,year_number FROM data11,year where nat_id1 = $nat1 and nat_id2 = $nat2 and gen_index_id = $pid and apok_dioikisi_id = $apok and perifereia_id = $perif and year.id = data11.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>