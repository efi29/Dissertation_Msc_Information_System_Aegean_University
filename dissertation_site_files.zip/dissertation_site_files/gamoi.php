<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΓΑΜΩΝ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide_gamoi.js"></script> 
  <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<style>
.container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 </head>
 <body>
 <ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li class="current"><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>


 <h3>ΔΕΙΚΤΕΣ ΓΑΜΩΝ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">
 <br>
 <br>
 <div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 5";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
</div>
<br>
<br>
<div class="select">
<select name="gen_index" id="gen_index" onchange="g1(this.value);">
<option value="">Διάλεξε Γενικό δείκτη</option>
  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 7 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>
</div>
<br>
<br>
<div id="choice_1" class="select">
 <select name="gender" id="gender" onchange="g2(this.value);">
 <option value="">Διάλεξε Φύλο(Γαμπρός/Νύφη)</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function g1(val)
{
	$.ajax({
	type: "POST", 
	url:"gamos1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#gender").html(data);
			$("#gender_1").html(data);
	}
});
}
</script>


<br>
 <br>
 <select name="nationality" id="nationality" onchange="g3(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function g2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"gamos2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#nationality").html(data);
	}
});
}
</script>

<br>
<br>
 <select name="apok_dioikisi" id="apok_dioikisi" onchange="g4(this.value);">
 <option value="">Αποκεντρωμένη Διοίκηση</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function g3(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#gender option:selected").val();

	$.ajax({
	type: "POST", 
	url:"gamos3.php",
	data:{'nat': val, 'pid':val2,'gender':val3},
	success: function(data)
	{
			$("#apok_dioikisi").html(data);
	}
});
}
</script>
<br>
<br>
 <select name="perifereia" id="perifereia" onchange="g5(this.value);">
 <option value="">Περιφέρεια</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function g4(val)
{

	$.ajax({
	type: "POST", 
	url:"gamos4.php",
	data:{'p': val},
	success: function(data)
	{
			$("#perifereia").html(data);
	}
});
}
</script>



<br>
<br>

 <select name="year">
 <option value="">Διάλεξε Έτος</option>
  
  <?php 	
	 $query = "SELECT * FROM year WHERE id IN (6,7,8,1,2,3) ORDER BY year_number ASC";
	 $result = mysqli_query($db, $query);
	
	 foreach($result as $year)
	 {
		 ?>
		 <option value="<?php echo $year["id"]; ?>"><?php echo $year["year_number"] ?></option>
	 <?php	 
	 }
 ?>
</select>
</div>

<div id="choice_2" class="select">
 <select name="gender_1" id="gender_1">
 <option value="">Διάλεξε Φύλο(Γαμπρός/Νύφη)</option>
 
</select>
</div>
<br><br/>
<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>
<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";
$gender = "";
$nationality = "";
$apok_dioikisi = "";
$perifereia = "";
$year = "";
$gender_1 ="";
$result1="";
$rows ="";
$result4="";

if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];
	$gender = $_POST['gender'];
	$nationality = $_POST['nationality'];
	$apok_dioikisi = $_POST['apok_dioikisi'];
	$perifereia = $_POST['perifereia'];
	$year = $_POST['year'];
	$gender_1 = $_POST['gender_1'];
	
	
	if ((empty($category) || empty($gen_index)  || empty($nationality)  || empty($gen_index) ||  empty($year)) && (empty($category)   || empty($gen_index)  || empty($gender_1) ) )
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{

	
	if ($gen_index == 30)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data5, spec_index, year WHERE data5.year_id = year.id and data5.spec_index_id = spec_index.id   and data5.cat_id = $category and data5.gen_index_id = $gen_index and  data5.gender_id = $gender and data5.nat_id = $nationality and data5.apok_dioikisi_id = $apok_dioikisi and data5.perifereia_id = $perifereia and data5.year_id = $year";
		$result = mysqli_query($db, $query);
		$sql2 = "SELECT dioikisi_name FROM apok_dioikisi WHERE id = $apok_dioikisi";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα αποκεντρωμένης διοίκησης:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
		$sql3 = "SELECT periferia_name FROM perifereia WHERE id = $perifereia";
		$result3 = mysqli_query($db, $sql3);
		echo "Έχετε επιλέξει ως Όνομα Περιφέρειας:";
		while($row = mysqli_fetch_row($result3))
			{
				echo "<td>".$row[0]."</td>";
			}
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data5, spec_index, year WHERE data5.year_id = year.id and data5.spec_index_id = spec_index.id   and data5.cat_id = $category and data5.gen_index_id = $gen_index and  data5.gender_id = $gender and data5.nat_id = $nationality and data5.apok_dioikisi_id = $apok_dioikisi and data5.perifereia_id = $perifereia";
		$result1 = mysqli_query($db, $query1);	

		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
	
	}
	else
	{
		$query = "SELECT   spec_index.index_name as Name, calc  FROM  data5, spec_index WHERE  data5.spec_index_id = spec_index.id   and data5.cat_id = $category and data5.gen_index_id = $gen_index and  data5.gender_id = $gender_1 ";
		$result = mysqli_query($db, $query);
		$query4 = "SELECT gender.g_name as Φύλλο, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data5, spec_index, gender WHERE data5.gender_id = gender.id and data5.spec_index_id = spec_index.id   and data5.cat_id = $category and data5.gen_index_id = $gen_index";
		$result4 = mysqli_query($db, $query4);
		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "</tr>";
		}
	}
		
		
	
	echo "</table>";

	
	/*$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    /*array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);*/
    /* Extract the information from $result */
	if($result1) {
	$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format


$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
}
}

//echo $jsonTable; 

	/*$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    /*array('label' => 'Φύλλο', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);*/
    /* Extract the information from $result */
	if($result4) {
		$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Φύλλο', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    foreach($result4 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (string) $r['Φύλλο']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format


$jsonTable2 = json_encode($table, JSON_UNESCAPED_UNICODE);	

mysqli_close($db);	

?>
<!--Load the Ajax API-->

	<br/><br/>
     <input type='button' class="button button1" value="Column Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
     <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: '',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
	  
	  //--------//
	   var data2 = new google.visualization.DataTable(<?=$jsonTable2?>);
	  var view2 = new google.visualization.DataView(data2);
	  
      var options2 = {
          title: '',
          is3D: 'true',
		  colors: ['#e0440e', '#e6693e'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart2 = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart2.draw(data2, options2);
	  var chart2 = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart2.draw(data2, options2);
    }
    </script>
 

 </div>


 <!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="display:none"></div>
	<div id="chart2div" style="display:none"></div>
</div>
<p><?php echo $error_message; ?></p>	

</body>
</html>