<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct nat_id,nat_name FROM data9,nationality where age_met =$id and gen_index_id = $pid and nationality.id = data9.nat_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε εθνικότητα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>