<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
		//$id = $_POST["id"];
	$pid = $_POST["pid"];
	$nat = $_POST["nat"];
	//$query = "SELECT distinct year_id,year_number FROM data2,year where gen_index_id = $pid and nat_id1 = $id and nat_id2 = $nat and year.id = data2.year_id";
	
$query = "SELECT distinct year_id,year_number FROM data2,year where year.id = data2.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>