<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];	
	$query = "SELECT distinct id,periferia_name FROM perifereia where apok_dioikisi_id = $id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε περιφέρεια</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["id"]; ?>"><?php echo $nationality["periferia_name"] ?></option>
	<?php		
		
		
	}
}

?>