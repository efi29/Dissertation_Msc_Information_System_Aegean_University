<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct nat_id2,nat_name FROM data11,nationality where nat_id1 = $id and gen_index_id = $pid and nationality.id = data11.nat_id2";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Εθνικότητα συνόλου εργατικού δυναμικού</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id2"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>