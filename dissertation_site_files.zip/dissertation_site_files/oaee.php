<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΟΑΕΕ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide.js"></script> 
  <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 
 </head>
 <body>
 <ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li class="current"><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>

 <h3>ΔΕΙΚΤΕΣ ΟΑΕΕ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">
 <br>
 <br>
 <div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 2";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
		<div class="select__arrow"></div>

</div>

<br>
<br>
<div class="select">
<select name="gen_index" id="gen_index" onchange="getcountry(this.value);getnat(this.value);getnat1_1(this.value);getnat3_1(this.value);getnat31(this.value);">
<option value="">Διάλεξε Γενικό δείκτη</option>
  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 4 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>
		<div class="select__arrow"></div>

</div>

<br>
<br>
<div class="select" id="nat_ins">
 <select name="nationality1" id="nationality1" onchange="getnat2(this.value);">
 <option value="">Διάλεξε εθνικότητα ασφαλισμένων</option>
</select>
		<div class="select__arrow"></div>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat(val)
{
	$.ajax({
	type: "POST", 
	url:"query2_15_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality1").html(data);
			$("#nationality1_2").html(data);
	}
});
}
</script>


<br>
<br>
 <select name="nationality2" id = "nationality2" onchange="getage(this.value);">
 <option value="">Διάλεξε εθνικότητα εργατικού δυναμικού</option>
</select>
		<div class="select__arrow"></div>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_15_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#nationality2").html(data);
	}
});
}
</script>






<br>
<br>
 <select name="year" id="year">
 <option value="">Διάλεξε Έτος</option>
</select>
<div class="select__arrow"></div>
</div>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getage(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality1 option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_15_3.php",
	data:{'id': val, 'pid':val2, 'nat':val3},
	success: function(data)
	{
			$("#year").html(data);
	}
});
}
</script>

<!-- end of first combo 15-nat1-nat2-year -->

<div id="nat_ins1" class="select">
 <select name="nationality1_1" id="nationality1_1" onchange="getnat2_1(this.value);">
 <option value="">Διάλεξε εθνικότητα ασφαλισμένων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat1_1(val)
{
	
	$.ajax({
	type: "POST", 
	url:"query2_16_1.php",
	data:{'id': val},
	success: function(data)
	{
			$("#nationality1_1").html(data);
	}
});
}
</script>




<br>
<br>
 <select name="nationality2_1" id="nationality2_1" onchange="getage1(this.value);">
 <option value="">Διάλεξε εθνικότητα συνόλου ασφαλισμένων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat2_1(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_16_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#nationality2_1").html(data);
	}
});
}
</script>

<br>
<br>
 <select name="year_1" id="year_1">
 <option value="">Διάλεξε Έτος</option>
</select>
</div>


<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getage1(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality1_1 option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_16_3.php",
	data:{'id': val, 'pid':val2, 'nat':val3},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>
<!-- end of combo 2 -->






<div id="nat_ins2" class="select">
 <select name="nationality1_2" id="nationality1_2" onchange="getnat3_2(this.value);">
 <option value="">Διάλεξε εθνικότητα ασφαλισμένων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat3_1(val)
{
	
	$.ajax({
	type: "POST", 
	url:"query2_17_1.php",
	data:{'id': val},
	success: function(data)
	{
			$("#nationality1_2").html(data);
	}
});
}
</script>



<br>
<br>
 <select name="nationality2_2" id="nationality2_2" onchange="getage2(this.value);">
 <option value="">Διάλεξε εθνικότητα συνόλου ασφαλισμένων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat3_2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_17_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#nationality2_2").html(data);
	}
});
}
</script>


<br>
<br>
 <select name="age_ins" id="age_ins" onchange="getyear3(this.value);">
 <option value="">Διάλεξε ηλικιακή ομάδα</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getage2(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality1_2 option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_17_3.php",
	data:{'nat2': val, 'nat1':val3, 'id':val2},
	success: function(data)
	{
			$("#age_ins").html(data);
	}
});
}
</script>





<br>
<br>



 <select name="year_2" id="year_2">
 <option value="">Διάλεξε Έτος</option>
</select>
</div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getyear3(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality1_2 option:selected").val();
	var val4 = $("#nationality2_2 option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_17_4.php",
	data:{'age': val, 'nat1':val3, 'id':val2,'nat2':val4},
	success: function(data)
	{
			$("#year_2").html(data);
	}
});
}
</script>




<!-- end of combo 3 -->







<div id="nat_ins3" class="select">
 
 <select name="nationality1_3" id="nationality1_3" onchange="getyear32(this.value);">
 <option value="">Διάλεξε εθνικότητα ασφαλισμένων</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getnat31(val)
{
	
	$.ajax({
	type: "POST", 
	url:"query2_18_1.php",
	data:{'id': val},
	success: function(data)
	{
			$("#nationality1_3").html(data);
	}
});
}
</script>



<br>
<br>
 
 
 
 <select name="year_3" id="year_3">
 <option value="">Διάλεξε Έτος Μεταβολής</option>
</select>
</div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getyear32(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_18_2.php",
	data:{'nat': val, 'id':val2},
	success: function(data)
	{
			$("#year_3").html(data);
	}
});
}
</script>


<div id="nat_ins4" class="select">
 <select name="tcn_country" id="tcn_country" onchange="getyear4(this.value);">
 <option value="">Διάλεξε κυρίαρχη χώρα υπηκόων τρίτων χωρών</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getcountry(val)
{
	
	$.ajax({
	type: "POST", 
	url:"query2_19_1.php",
	data:{'id': val},
	success: function(data)
	{
			$("#tcn_country").html(data);
	}
});
}
</script>





<br>
<br>
 <select name="year_4" id = "year_4">
 <option value="">Διάλεξε Έτος</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getyear4(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query2_19_2.php",
	data:{'nat': val, 'id':val2},
	success: function(data)
	{
			$("#year_4").html(data);
	}
});
}
</script>








</div>
<br><br/>
<div  class="select">
<input type="submit" name="submit" id="submit" value="Υποβολή" >
</div>
</form>
<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";
$nationality1 = "";
$nationality2 = "";
$year= "";

$nationality1_1 = "";
$nationality2_1 = "";
$year_1 = "";

$nationality1_2 = "";
$nationality2_2 = "";
$age_ins = "";

$year_2 = "";
$nationality1_3 = "";

$year_3 = "";
$tcn_country = "";
$year_4 = "";
$result1 = "";

if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];
	$nationality1 = $_POST['nationality1'];	
	$nationality2 = $_POST['nationality2'];
	$year= $_POST['year'];
	
	$nationality1_1 = $_POST['nationality1_1'];
	$nationality2_1 = $_POST['nationality2_1'];
	$year_1= $_POST['year_1'];
	
	$nationality1_2 = $_POST['nationality1_2'];
	$nationality2_2 = $_POST['nationality2_2'];
	$age_ins= $_POST['age_ins'];
	$year_2= $_POST['year_2'];
	
	$nationality1_3 = $_POST['nationality1_3'];
	$year_3= $_POST['year_3'];
	
	$tcn_country= $_POST['tcn_country'];
	$year_4= $_POST['year_4'];

	if ((empty($category) || empty($gen_index)  || empty($nationality1)  || empty($nationality2) || empty($year)) &&  (empty($category) || empty($gen_index)  || empty($nationality1_1)  || empty($nationality2_1) || empty($year_1)) &&(empty($category) || empty($gen_index)  || empty($nationality1_2)  || empty($nationality2_2) || empty($year_2)) && (empty($category) || empty($gen_index)  || empty($nationality1_3)  || empty($year_3)) &&  (empty($category) || empty($gen_index)    || empty($tcn_country) || empty($year_4))) 
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{
	if ($gen_index == 15) 
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1 and data2.nat_id2 = $nationality2 and data2.year_id = $year";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1 and data2.nat_id2 = $nationality2";
		$result1 = mysqli_query($db, $query1);
	}
	
	
 	else if($gen_index == 16)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_1 and data2.nat_id2 = $nationality2_1 and data2.year_id = $year_1";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_1 and data2.nat_id2 = $nationality2_1";
		$result1 = mysqli_query($db, $query1);

	}
	else if($gen_index == 17)
	{
		$query = "SELECT  year.year_number as Year,  spec_index.index_name as Name, calc  FROM  data2, spec_index,  year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_2 and data2.nat_id2 = $nationality2_2 and data2.age_ins_id = $age_ins and data2.year_id = $year_2";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_2 and data2.nat_id2 = $nationality2_2 and data2.age_ins_id = $age_ins";
		$result1 = mysqli_query($db, $query1);
	
	}
	else if($gen_index == 18)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_3 and data2.year_id = $year_3";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.nat_id1 = $nationality1_3";
		$result1 = mysqli_query($db, $query1);
	}
	else
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.tcn_country_id = $tcn_country and data2.year_id = $year_4";
		$sql2 = "SELECT tcn_country_name FROM tcn_country WHERE id = $tcn_country";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα χώρας:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
			$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data2, spec_index, year WHERE data2.year_id = year.id and data2.spec_index_id = spec_index.id   and data2.cat_id = $category and data2.gen_index_id = $gen_index and  data2.tcn_country_id = $tcn_country";
			$result1 = mysqli_query($db, $query1);
	} 
		
	
		
		$result = mysqli_query($db, $query);
		if(! $result) 
			{
				die("SQL Error: " . mysqli_error($db));
			}
		echo "<br>";
		
	
		
		echo "<br>";

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";
			

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
		
	
	


	

	
echo "</table>";

	$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format
$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
}
}
//echo $jsonTable; 
mysqli_close($db);
 ?>
	
<!--Load the Ajax API-->
	<br/>

     <input type='button' class="button button1" value="Column Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
     <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	 
	 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το έτος',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
    }

    </script>

	 
	 </div>

 <p><?php echo $error_message; ?></p>
 <!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="display:none"></div>
    <div id="chart2div" style="display:none"></div>
</body>
</html>