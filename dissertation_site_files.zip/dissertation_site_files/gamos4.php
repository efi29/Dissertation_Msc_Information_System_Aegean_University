<?php
include_once "connection.php";


if(!empty($_POST["p"]))
{
	$id = $_POST["p"];
	
	$query = "SELECT id,periferia_name FROM perifereia where apok_dioikisi_id = $id ";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Αποκεντρωμένη Διοίκηση</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["id"]; ?>"><?php echo $nationality["periferia_name"] ?></option>
	<?php		
		
		
	}
}

?>