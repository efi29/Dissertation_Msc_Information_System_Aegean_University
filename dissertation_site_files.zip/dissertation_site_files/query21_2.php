<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct gender_id2,g_name FROM data3,gender where gen_index_id = $pid and gender_id1 = $id and gender.id = data3.gender_id2";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε φύλο συνόλου</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gender_id2"]; ?>"><?php echo $nationality["g_name"] ?></option>
	<?php		
		
		
	}
}

?>