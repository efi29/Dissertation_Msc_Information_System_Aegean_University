/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
	
	if ($("#gen_index").val() == 97)
		
	{
		
		$("#choice_1").show()  ;
		
	}
        
    else
	{
		$("#choice_1").hide();
	}
        
	
	if ($("#gen_index").val() == 98)
	{
		$("#choice_2").show()  ;
	}
        
    else
	{
		$("#choice_2").hide();
	}
        
	
	if ($("#gen_index").val() == 99)
	{
		$("#choice_3").show()  ;
	}
        
    else
	{
		$("#choice_3").hide();
	}
	
	
	if ($("#gen_index").val() == 100)
	{
		$("#choice_4").show()  ;
	}
        
    else
	{
		$("#choice_4").hide();
	}
	
	if ($("#gen_index").val() == 101)
	{
		$("#choice_5").show()  ;
	}
        
    else
	{
		$("#choice_5").hide();
	}
	
	if ($("#gen_index").val() == 102 )
	{
		$("#choice_6").show()  ;
	}
        
    else
	{
		$("#choice_6").hide();
	}
	
	
	if ($("#gen_index").val() == 103)
	{
		$("#choice_7").show()  ;
	}
        
    else
	{
		$("#choice_7").hide();
	}
	
	if ($("#gen_index").val() == 104 )
	{
		$("#choice_8").show()  ;
	}
        
    else
	{
		$("#choice_8").hide();
	}
	
	if ($("#gen_index").val() == 105 )
	{
		$("#choice_9").show()  ;
	}
        
    else
	{
		$("#choice_9").hide();
	}
	
	if ($("#gen_index").val() == 106 )
	{
		$("#choice_10").show()  ;
	}
        
    else
	{
		$("#choice_10").hide();
	}
	
	if ($("#gen_index").val() == 107 )
	{
		$("#choice_11").show()  ;
	}
        
    else
	{
		$("#choice_11").hide();
	}
	
	if ($("#gen_index").val() == 108 || ($("#gen_index").val() == 109) )
	{
		$("#choice_12").show()  ;
	}
        
    else
	{
		$("#choice_12").hide();
	}
	
	
}



