<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct nat_id1,nat_name  FROM data12,nationality where gen_index_id = $pid and vathmida_ekpaideysis_id = $id and nationality.id = data12.nat_id1";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Εθνικότητα μαθητών</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id1"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>