<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$nat1 = $_POST["nat1"];
	$nat2 = $_POST["nat2"];
	$age = $_POST["age"];
	$query = "SELECT distinct year_id,year_number FROM data2,year where gen_index_id = $id and nat_id1 = $nat1 and nat_id2 = $nat2 and  age_ins_id= $age and year.id = data2.year_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>