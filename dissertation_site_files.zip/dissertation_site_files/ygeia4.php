<?php
include_once "connection.php";


if(!empty($_POST["pid"]))
{
	
	$id = $_POST["pid"];
	$nat1 = $_POST["nat1"];
	$nat2 = $_POST["nat2"];

	$query = "SELECT distinct year_id,year_number FROM data6,year where gen_index_id = $id and $nat1 = data6.nat_id1 and $nat2 = data6.nat_id2 and data6.year_id = year.id";
	$result = mysqli_query($db, $query);
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>