<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct age_met,age_met_name  FROM data9,age_met where gen_index_id = $id and age_met.id = data9.age_met";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε ηλικιακή ομάδα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["age_met"]; ?>"><?php echo $nationality["age_met_name"] ?></option>
	<?php		
		
		
	}
}

?>