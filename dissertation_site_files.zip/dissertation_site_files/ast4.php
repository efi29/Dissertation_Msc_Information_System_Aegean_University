<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$y = $_POST["y"];
	$query = "SELECT distinct tcn_country_prosfyges_id,tcn_country_name_prosfyges FROM data14,tcn_country_prosfyges where tcn_country_prosfyges.id = data14.tcn_country_prosfyges_id and data14.year_id = $y and gen_index_id = $pid and year_id = $id ";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Υπηκοότητα</option>

	
	<?php
	$i=1;
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["tcn_country_prosfyges_id"]; ?>"><?php echo $nationality["tcn_country_name_prosfyges"] ?></option>
	<?php		
		$i = $i + 1;
		
	}
}

?>