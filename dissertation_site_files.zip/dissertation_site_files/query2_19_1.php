<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct tcn_country_id,tcn_country_name FROM data2,tcn_country where gen_index_id = $id and tcn_country.id = data2.tcn_country_id";
	$result = mysqli_query($db, $query); 
	?>
	
		<option value="" selected>Διάλεξε κυρίαρχη χώρα υπηκόων τρίτων χωρών</option>

	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["tcn_country_id"]; ?>"><?php echo $nationality["tcn_country_name"] ?></option>
	<?php		
		
		
	}
}

?>