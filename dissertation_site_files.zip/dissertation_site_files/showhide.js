/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
	
	if ($("#gen_index").val() == 15)
		
	{
		
		$("#nat_ins").show()  ;
		
	}
        
    else
	{
		$("#nat_ins").hide();
	}
        
	
	if ($("#gen_index").val() == 16)
	{
		$("#nat_ins1").show()  ;
	}
        
    else
	{
		$("#nat_ins1").hide();
	}
        
	
	if ($("#gen_index").val() == 17)
	{
		$("#nat_ins2").show()  ;
	}
        
    else
	{
		$("#nat_ins2").hide();
	}
	
	
	if ($("#gen_index").val() == 18)
	{
		$("#nat_ins3").show()  ;
	}
        
    else
	{
		$("#nat_ins3").hide();
	}
	
	if ($("#gen_index").val() == 19)
	{
		$("#nat_ins4").show()  ;
	}
        
    else
	{
		$("#nat_ins4").hide();
	}
	
	 

		
}



