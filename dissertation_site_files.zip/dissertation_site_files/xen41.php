<?php
include_once "connection.php";


if(!empty($_POST["pid"]))
{
	$id = $_POST["pid"];
	$middle = $_POST["id"];
	$sex = $_POST["sex"];
	$query = "SELECT year_id, year_number FROM data7,year where data7.gen_index_id = $id and data7.middle_id = $middle and data7.gender_id = $sex and data7.year_id = year.id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>