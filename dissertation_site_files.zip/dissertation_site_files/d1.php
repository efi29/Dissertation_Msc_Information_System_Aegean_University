<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct gender_id1,g_name  FROM data10,gender where gen_index_id = $id and gender.id = data10.gender_id1";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Φύλο</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gender_id1"]; ?>"><?php echo $nationality["g_name"] ?></option>
	<?php		
		
		
	}
}

?>