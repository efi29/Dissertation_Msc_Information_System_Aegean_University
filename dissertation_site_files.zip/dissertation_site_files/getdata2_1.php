<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT * FROM gen_index where category_id = $id";
	$result = mysqli_query($db, $query); 
	?>
	
	<option value="">Διάλεξε Γενικό Δείκτη</option>
	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["id"]; ?>"><?php echo $nationality["index_name"] ?></option>
	<?php		
		
		
	}
}

?>