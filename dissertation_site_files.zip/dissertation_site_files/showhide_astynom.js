/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
	
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#gen_index").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
		
	if ($("#gen_index").val() == 116 || ($("#gen_index").val() == 118)  || ($("#gen_index").val() == 120) || ($("#gen_index").val() == 122) || ($("#gen_index").val() == 128) || ($("#gen_index").val() == 130) || ($("#gen_index").val() == 131) || ($("#gen_index").val() == 132) || ($("#gen_index").val() == 133) || ($("#gen_index").val() == 134) || ($("#gen_index").val() == 135) || ($("#gen_index").val() == 136) || ($("#gen_index").val() == 137) || ($("#gen_index").val() == 138) || ($("#gen_index").val() == 139) || ($("#gen_index").val() == 140) || ($("#gen_index").val() == 141) || ($("#gen_index").val() == 142) || ($("#gen_index").val() == 143) || ($("#gen_index").val() == 144) || ($("#gen_index").val() == 145) || ($("#gen_index").val() == 146) || ($("#gen_index").val() == 147) || ($("#gen_index").val() == 148) || ($("#gen_index").val() == 149) || ($("#gen_index").val() == 150) || ($("#gen_index").val() == 151) || ($("#gen_index").val() == 152) || ($("#gen_index").val() == 153) || ($("#gen_index").val() == 154) || ($("#gen_index").val() == 155) || ($("#gen_index").val() == 156) || ($("#gen_index").val() == 157) || ($("#gen_index").val() == 158) || ($("#gen_index").val() == 159) || ($("#gen_index").val() == 161) || ($("#gen_index").val() == 162) )
		
	{
		
		$("#choice_1").show()  ;
		$("#choice_2").hide()  ;
		$("#choice_3").hide()  ;
		$("#choice_4").hide()  ;
		$("#choice_5").hide()  ;
		$("#choice_6").hide()  ;
		
		
	}
        
    else
	{
		$("#choice_1").hide()  ;
		$("#choice_2").hide()  ;
		$("#choice_3").hide()  ;
		$("#choice_4").hide()  ;
		$("#choice_5").hide()  ;
		$("#choice_6").hide()  ;
		
	}
	

	
	
	if ($("#gen_index").val() == 124 || ($("#gen_index").val() == 125) || ($("#gen_index").val() == 126) || ($("#gen_index").val() == 127) || ($("#gen_index").val() == 163) ) 
	
	{
		
		
		$("#choice_3").show()  ;
	
		
	}
        
    else
	{
		
		$("#choice_3").hide()  ;
	
	}
        
	if ($("#gen_index").val() == 117 || ($("#gen_index").val() == 119) || ($("#gen_index").val() == 121) || ($("#gen_index").val() == 123) || ($("#gen_index").val() == 129) )
	{
		$("#choice_2").show()  ;
	}
        
    else
	{
		$("#choice_2").hide();
	}
	
	
	if ($("#gen_index").val() == 167 || ($("#gen_index").val() == 168) || ($("#gen_index").val() == 169) || ($("#gen_index").val() == 170) || ($("#gen_index").val() == 171) )
	{
		$("#choice_4").show()  ;
	}
        
    else
	{
		$("#choice_4").hide();
	}
	
	if ($("#gen_index").val() == 160 )
	{
		$("#choice_5").show()  ;
	}
        
    else
	{
		$("#choice_5").hide();
	}
	
	
	if ($("#gen_index").val() == 164 || ($("#gen_index").val() == 165) || ($("#gen_index").val() == 166) )
	{
		$("#choice_6").show()  ;
	}
        
    else
	{
		$("#choice_6").hide();
	}
	
	
	
	
}



