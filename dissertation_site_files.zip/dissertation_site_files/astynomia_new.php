<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΑΣΤΥΝΟΜΙΑΣ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide_astynom.js"></script> 
<script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="eisodima.js"></script> 
  <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<style>
<style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 </head>
 <body>
<ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li  ><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li ><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li class="current"><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>
 <h3>ΔΕΙΚΤΕΣ ΑΣΤΥΝΟΜΙΑΣ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">

<div class="select">
	<select name="category" onchange="getId(this.value);">
	<option value="">Διάλεξε κατηγορία</option>
  
	<?php
	
	$query = "SELECT * FROM category WHERE theme_id = 14";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
	?>
	</select>
</div>
<br/><br/>

<div class="select">
<select name="gen_index" id="gen_index" onchange="ast1(this.value);ast25(this.value);ast3(this.value);ast5(this.value);ast55(this.value);ast6(this.value)">
<option value="">Διάλεξε Γενικό δείκτη*</option>
</select>
</div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function getId(val)//, οποτε περναμε τη value στο ajax
{
//we create ajax function
	$.ajax({
	type: "POST",
	//getdata7.php είναι το αρχείο όπου κάνουμε το query για το δεύτερο drop down 
	url:"getdata_astynomia.php",
	data:"id="+val,
	success: function(data14)//εκτέλεση της functions, αν success
	{
			$("#gen_index").html(data14);
	}
	
	
	
});
	
	
}
</script>
<br/><br/>

<div id="choice_1" class="select">
	<select name="nationality_1" id="nationality_1" onchange="ast30(this.value);">
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
	<div class="select__arrow"></div>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast1(val)
{
	$.ajax({
	type: "POST", 
	url:"ast1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_1").html(data);
	}
});
}
</script>
<br/><br/>
	<select name="year_1" id="year_1">
	<option value="">Διάλεξε Έτος </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast30(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"ast30.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_2" class="select">

 <select name="nationality_2" id="nationality_2" onchange="ast2(this.value)";>
 <option value="">Διάλεξε εθνικότητα</option>
  </select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast25(val)
{
	$.ajax({
	type: "POST", 
	url:"ast25.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_2").html(data);
	}
});
}
</script>
<br/><br/>
 
 <select name="year_2" id="year_2">
<option value="">Διάλεξε Έτος Μεταβολής</option>
  
  </select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"ast2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_2").html(data);
	}
});
}
</script>
<br/><br/>
</div>



<div id="choice_3" class="select">
	<select name="year_3" id="year_3" onchange="ast4(this.value);">
	<option value="">Διάλεξε Έτος  </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast3(val)
{
	$.ajax({
	type: "POST", 
	url:"ast3.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_3").html(data);
	}
});
}
</script>



<br/><br/>
	<select name="tcn_country" id="tcn_country">
	<option value="">Διάλεξε Υπηκοότητα </option>
	</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast4(val)
{
	var val3 = $("#year_3 option:selected").val();
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"ast4.php",
	data:{'id': val, 'pid':val2, 'y':val3},
	success: function(data)
	{
			$("#tcn_country").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_4" class="select">
	
	<select name="year_4" id="year_4" onchange="ast6(this.value);">
	<option value="">Διάλεξε Έτος </option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast5(val)
{
	$.ajax({
	type: "POST", 
	url:"ast5.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_4").html(data);
	}
});
}
</script>
<br/><br/>
</div>

<div id="choice_5" class="select">
	<select name="nationality_5a" id="nationality_5a" onchange="ast7(this.value)";>
	<option value="">Διάλεξε εθνικότητα</option>
	</select>
	
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast6(val)
{
	
	$.ajax({
	type: "POST", 
	url:"ast6.php",
	data:{'id': val},
	success: function(data)
	{
			$("#nationality_5a").html(data);
	}
});
}
</script>
	
	
<br/><br/>
	<select name="nationality_5b" id="nationality_5b" onchange="ast8(this.value);">
	<option value="">Διάλεξε εθνικότητα 100</option>
	</select>
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast7(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"ast7.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#nationality_5b").html(data);
	}
});
}
</script>
<br/><br/>
	<select name="year_5" id="year_5">
	<option value="">Διάλεξε Έτος </option>

</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast8(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality_5a option:selected").val();

	$.ajax({
	type: "POST", 
	url:"ast8.php",
	data:{'id': val, 'pid':val2,'nat':val3},
	success: function(data)
	{
			$("#year_5").html(data);
	}
});
}
</script>

<br/><br/>
</div>

<div id="choice_6" class="select">
	
	
	<select name="year_6" id="year_6">
	<option value="">Διάλεξε Έτος Μεταβολής </option>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function ast55(val)
{
	$.ajax({
	type: "POST", 
	url:"ast5.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_6").html(data);
	}
});
}
</script>  
</select>
<br/><br/>
</div>


<br/><br/>

<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>

<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";

	$nationality_1 = "";
	$year_1= "";
	
	$nationality_2 = "";
	$year_2= "";
	
	$tcn_country= "";
	$year_3= "";
	
	$year_4= "";
	
	$nationality_5a = "";
	$nationality_5b = "";
	$year_5= "";
	
	$year_6= "";

if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];

	$nationality_1 = $_POST['nationality_1'];
	$year_1= $_POST['year_1'];
	
	$nationality_2 = $_POST['nationality_2'];
	$year_2= $_POST['year_2'];
	
	$tcn_country= $_POST['tcn_country'];
	$year_3= $_POST['year_3'];
	
	$year_4= $_POST['year_4'];
	
	$nationality_5a = $_POST['nationality_5a'];
	$nationality_5b = $_POST['nationality_5b'];
	$year_5= $_POST['year_5'];
	
	$year_6= $_POST['year_6'];
	
	if ((empty($category) || empty($gen_index)    || empty($nationality_1) || empty($year_1) ) && (empty($category) || empty($gen_index)    || empty($nationality_2) || empty($year_2) ) && (empty($category) || empty($gen_index)    || empty($tcn_country) || empty($year_3) ) && (empty($category) || empty($gen_index) || empty($year_4) ) && (empty($category) || empty($gen_index) || empty($nationality_5a) || empty($nationality_5b) || empty($year_5)) && (empty($category) || empty($gen_index) || empty($year_6) ))
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{
	
	if ($gen_index == 116 || $gen_index == 118 || $gen_index == 120 || $gen_index == 122 ||  $gen_index == 128 || $gen_index == 130 || $gen_index == 131 || $gen_index == 132 || $gen_index == 133 || $gen_index == 134 || $gen_index == 135 || $gen_index == 136 || $gen_index == 137 || $gen_index == 138 || $gen_index == 139 || $gen_index == 140 || $gen_index == 141 || $gen_index == 142 || $gen_index == 143 || $gen_index == 144 || $gen_index == 145 || $gen_index == 146 || $gen_index == 147 || $gen_index == 148 || $gen_index == 149 || $gen_index == 150 || $gen_index == 151 || $gen_index == 152 || $gen_index == 153 || $gen_index == 154 || $gen_index == 155 || $gen_index == 156 || $gen_index == 157 || $gen_index == 158 || $gen_index == 159 || $gen_index == 161 || $gen_index == 162)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.nat_id = $nationality_1 and data14.year_id = $year_1";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.nat_id = $nationality_1 ";
		$result1 = mysqli_query($db, $query1);
		
	}
	
	else if($gen_index == 117 || $gen_index == 119 || $gen_index == 121 || $gen_index == 123 || $gen_index == 129)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.nat_id = $nationality_2 and data14.year_id = $year_2";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.nat_id = $nationality_2 ";
		$result1 = mysqli_query($db, $query1);
	
	}
	
	else if($gen_index == 124 || $gen_index == 125 || $gen_index == 126 || $gen_index == 127 || $gen_index == 163)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.tcn_country_prosfyges_id = $tcn_country and data14.year_id = $year_3";
		
		$sql2 = "SELECT tcn_country_name_prosfyges FROM tcn_country_prosfyges WHERE id = $tcn_country";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα χώρας:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
		
		
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index and data14.tcn_country_prosfyges_id = $tcn_country ";
		$result1 = mysqli_query($db, $query1);
		
	}
	
	
	
	else if($gen_index == 160 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  and data14.nat_id = $nationality_5a and data14.nat_id2 = $nationality_5b and data14.year_id = $year_5";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  and data14.nat_id = $nationality_5a and data14.nat_id2 = $nationality_5b ";
		$result1 = mysqli_query($db, $query1);
		
	}
	
	else if ($gen_index == 164 || $gen_index == 165 || $gen_index == 166 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  and data14.year_id = $year_6";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  ";
		$result1 = mysqli_query($db, $query1);
				
				
	}
	
	else if($gen_index == 167 || $gen_index == 168  || $gen_index == 169|| $gen_index == 170 || $gen_index == 171 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  and data14.year_id = $year_4";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη  FROM  data14, spec_index, year WHERE data14.year_id = year.id and data14.spec_index_id = spec_index.id   and data14.cat_id = $category and data14.gen_index_id = $gen_index  ";
		$result1 = mysqli_query($db, $query1);
		
	}
		$result = mysqli_query($db, $query);
		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
	


	

	
echo "</table>";

$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format
$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
}
}

//echo $jsonTable; 
	
mysqli_close($db);	

?>

<!--Load the Ajax API-->

<br/>
	<input type='button' class="button button1" value="Bar Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
    <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το έτος',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
    }
    </script>
</div>

<p><?php echo $error_message; ?></p>

 <!--this is the div that will hold the pie chart-->
     <div id="chart_div" style="width: 1200px; height: 800px; display:none"></div>
	<div id="chart2div"  style="width: 900px; height: 500px; display:none"></div>	


</body>
</html>