<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	
	$id = $_POST["pid"];
	$year = $_POST["id"];
	$query = "SELECT distinct year_id,year_number FROM data6,year where gen_index_id = $id and $year = data6.nat_id1 and data6.year_id = year.id";
	$result = mysqli_query($db, $query);
	?>
			<option value="" selected>Διάλεξε Έτος</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>