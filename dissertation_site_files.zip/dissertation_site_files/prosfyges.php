<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΠΡΟΣΦΥΓΩΝ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide_prosfyges.js"></script> 
 <link href="style.css" rel="stylesheet" type="text/css" media="screen" />

 </head>
 <body>
<ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li  ><a href="oaee.php">ΟΑΕΕ</a></li>
<li ><a href="ithageneia.php">Ιθαγένεια</a></li>
<li class="current"><a href="prosfyges.php">Πρόσφυγες</a></li>
<li><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>
<style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 <h3>ΔΕΙΚΤΕΣ ΠΡΟΣΦΥΓΩΝ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">
 <br>
 <br>
 <div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 4";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
</div>
<br>
<br>
<div class="select">
<select name="gen_index" id="gen_index" onchange="p11(this.value);p21(this.value);p31(this.value);p41(this.value);p51(this.value);p61(this.value);p71(this.value);">
<option value="">Διάλεξε Γενικό δείκτη</option>
  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 6 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>
</div>
<br>
<br>

<div id="choice_1" class="select">
 <select name="nationality" id="nationality" onchange="p12(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
 </select>
 <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p11(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality").html(data);
	}
});
}
</script>
 
 
 

 <br>
 <br>
 <select name="year" id="year">
<option value="">Διάλεξε Έτος Μεταβολής</option>
  
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p12(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year").html(data);
	}
});
}
</script>
<br>
<br>
</div>

<div id="choice_2" class="select">
 <select name="nationality_1" id="nationality_1" onchange="p22(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
 </select>
  <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p21(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_1").html(data);
	}
});
}
</script>
 
 <br>
 <br>
 <select name="year_1" id="year_1">
<option value="">Διάλεξε Έτος Μεταβολής</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p22(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>
<br>
<br>
</div>

<div id="choice_3" class="select">
 <select name="nationality_2" id="nationality_2" onchange="p32(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
 </select>
 <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p31(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_2").html(data);
	}
});
}
</script>
 <br>
 <br>
 <select name="year_2" id="year_2">
 <option value="">Διάλεξε Έτος</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p32(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_2").html(data);
	}
});
}
</script>
</div>

<div id="choice_4" class="select">
 <select name="nationality_3" id="nationality_3" onchange="p42(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
 </select>
  <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p41(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_3").html(data);
	}
});
}
</script>
 <br>
 <br>
 <select name="year_3" id="year_3">
<option value="">Διάλεξε Έτος Μεταβολής</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p42(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_3").html(data);
	}
});
}
</script>
</div>

<div id="choice_5" class="select">
 <select name="nationality_4" id="nationality_4" onchange="p52(this.value);">
 <option value="">Διάλεξε εθνικότητα</option>
 </select>
   <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p51(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#nationality_4").html(data);
	}
});
}
</script>
 <br>
 <br>
<select name="year_4" id="year_4">
<option value="">Διάλεξε Έτος</option>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p52(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#year_4").html(data);
	}
});
}
</script>
</select>
</div>

<div id="choice_6" class="select">
 <select name="year_5" id="year_5" onchange="p62(this.value);">
<option value="">Διάλεξε Έτος</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p61(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_3.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year_5").html(data);
			$("#year_6").html(data);

			
	}
});
}
</script>
<br>
<br>
 <select name="tcn_country_prosfyges" id="tcn_country_prosfyges">
 <option value="">Διάλεξε υπηκοότητα</option>
 </select>
 <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p62(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query23_4.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#tcn_country_prosfyges").html(data);
	}
});
}
</script>
 </div>
 
 <div id="choice_7" class="select">
 <select name="year_6" id="year_6" onchange="p72(this.value);">
<option value="">Διάλεξε Έτος</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p71(val)
{
	$.ajax({
	type: "POST", 
	url:"query23_33.php",
	data:"id="+val,
	success: function(data)
	{
			
			$("#year_6").html(data);

			
	}
});
}
</script>
<br>
<br>


 <select name="tcn_country_prosfyges_1" id="tcn_country_prosfyges_1">
 <option value="">Διάλεξε υπηκοότητα</option>
 </select>
  <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function p72(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query103.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#tcn_country_prosfyges_1").html(data);
	}
});
}
</script>
 </div>
<br>
<br>
<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>
<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";
$nationality ="";
$year= "";

$nationality_1 ="";
$year_1= "";

$nationality_2 ="";
$year_2= "";

$nationality_3 ="";
$year_3= "";

$nationality_4 ="";
$year_4= "";

$year_5= "";
$tcn_country_prosfyges = "";


$year_6= "";
$tcn_country_prosfyges_1 = "";

$table= "";
$result1 = "";

if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];
	$nationality = $_POST['nationality'];
	$year= $_POST['year'];
	
	$nationality_1 = $_POST['nationality_1'];
	$year_1= $_POST['year_1'];
	
	
	$nationality_2 = $_POST['nationality_2'];
	$year_2= $_POST['year_2'];
	
	$nationality_3 = $_POST['nationality_3'];
	$year_3= $_POST['year_3'];
	
	$nationality_4 = $_POST['nationality_4'];
	$year_4= $_POST['year_4'];
	
	$year_5= $_POST['year_5'];
	$tcn_country_prosfyges = $_POST['tcn_country_prosfyges'];
	
	$year_6= $_POST['year_6'];
	$tcn_country_prosfyges_1 = $_POST['tcn_country_prosfyges_1'];
	
	if ((empty($category) || empty($gen_index)  || empty($nationality)  ||  empty($year)) && (empty($category)  || empty($nationality_1)  || empty($year_1)) && (empty($category) ||  empty($gen_index) || empty($nationality_2)  || empty($year_2)) && (empty($category) ||  empty($gen_index) || empty($nationality_3)  || empty($year_3)) && (empty($category) ||  empty($gen_index) || empty($nationality_4)  || empty($year_4)) && (empty($category) ||  (empty($gen_index) || empty($year_5)  || empty($tcn_country_prosfyges)) && (empty($category) ||  empty($gen_index) || empty($year_6)  || empty($tcn_country_prosfyges_1) ) ))
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}
	else
	{

	
	if ($gen_index == 23  )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality and data4.year_id = $year";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if ($gen_index == 24 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_1 and data4.year_id = $year_1";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_1";
		$result1 = mysqli_query($db, $query1);
	}
	
	
	
	else if($gen_index == 25 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_2 and data4.year_id = $year_2";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_2";
		$result1 = mysqli_query($db, $query1);
	}
	
	
	
	else if($gen_index == 26 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_3 and data4.year_id = $year_3";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_3";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 27 )
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_4 and data4.year_id = $year_4";
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.nat_id = $nationality_4";
		$result1 = mysqli_query($db, $query1);
	}
	
	else if($gen_index == 28)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.year_id = $year_5 and data4.tcn_country_prosfyges_id = $tcn_country_prosfyges";
		$sql2 = "SELECT tcn_country_name_prosfyges FROM tcn_country_prosfyges WHERE id = $tcn_country_prosfyges";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα χώρας:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.tcn_country_prosfyges_id = $tcn_country_prosfyges";
		$result1 = mysqli_query($db, $query1);
	}
	
	else 
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data4, spec_index, year WHERE data4.year_id = year.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.year_id = $year_6 and data4.tcn_country_prosfyges_id = $tcn_country_prosfyges_1";
		$sql2 = "SELECT tcn_country_name_prosfyges FROM tcn_country_prosfyges WHERE id = $tcn_country_prosfyges_1";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα χώρας:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
		$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM data4, spec_index, year, tcn_country_prosfyges WHERE data4.year_id = year.id and data4.tcn_country_prosfyges_id = tcn_country_prosfyges.id and data4.spec_index_id = spec_index.id   and data4.cat_id = $category and data4.gen_index_id = $gen_index and data4.tcn_country_prosfyges_id = $tcn_country_prosfyges_1 ";
		$result1 = mysqli_query($db, $query1);
	}
	
	
		$result = mysqli_query($db, $query);
		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
	echo "</table>";

	$rows = array();
	$table = array();
 
	$table['cols'] = array(

    

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format

$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
	}
}
//echo $jsonTable; 
	
mysqli_close($db);	

?>
<!--Load the Ajax API-->
	<br/><br/>
     <input type='button' class="button button1" value="Column Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
     <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	 
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	
	function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το έτος',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
	   
    }
    </script>
 

 </div>


 <!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="display:none"></div>
	<div id="chart2div" style="display:none"></div>
<p><?php echo $error_message; ?></p>	

</body>
</html>