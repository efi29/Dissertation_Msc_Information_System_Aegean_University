<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$query = "SELECT distinct nat_id2,nat_name FROM data2,nationality where gen_index_id = $pid and nat_id1 = $id and nationality.id = data2.nat_id2";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε εθνικότητα συνόλου ασφαλισμένων</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["nat_id2"]; ?>"><?php echo $nationality["nat_name"] ?></option>
	<?php		
		
		
	}
}

?>