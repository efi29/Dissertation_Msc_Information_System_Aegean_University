<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct nat_id1,nat_name FROM data2,nationality where gen_index_id = '".$id."' and data2.nat_id1 = nationality.id";
	$result = mysqli_query($db, $query);
	?> 
	
	<option value="">Διάλεξε Εθνικότητα</option>
	
	<?php
	foreach($result as $data2)
	{
	?>
		
		<option value="<?php echo $data2["nat_id1"]; ?>"><?php echo $data2["nat_name"] ?></option>
	<?php		
		
		
	}
}
?>