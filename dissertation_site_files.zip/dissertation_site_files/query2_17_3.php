<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$nat1 = $_POST["nat1"];
	$nat2 = $_POST["nat2"];
	$query = "SELECT distinct age_ins_id,age_ins_name FROM data2,age_ins where gen_index_id = $id and nat_id1 = $nat1 and nat_id2 = $nat2 and age_ins.id = data2.age_ins_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε ηλικιακή ομάδα</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["age_ins_id"]; ?>"><?php echo $nationality["age_ins_name"] ?></option>
	<?php		
		
		
	}
}

?>