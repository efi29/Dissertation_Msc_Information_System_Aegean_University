<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΙΘΑΓΕΝΕΙΑΣ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <script language="javascript" type="text/javascript" src="showhide_ithageneia.js"></script> 
   <link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<style>

.container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 </head>
 <body>
<ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li  ><a href="oaee.php">ΟΑΕΕ</a></li>
<li class="current"><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>
 <h3>ΔΕΙΚΤΕΣ ΙΘΑΓΕΝΕΙΑΣ</h3>
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">
 <br>
 <br>
 <p><em>Στον πρώτο γενικό δείκτη δεν γίνεται γραφική αναπαράσταση καθώς δεν υπάρχει ένας παράγοντας με τον οποίο μπορεί να συγκριθεί.</em></p>
  <p><em>To ίδιο ισχύει και για το δεύτερο γενικό δείκτη</em></p>
 <div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 3";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
</div>
<br>
<br>
<div class="select">

<select name="gen_index" id="gen_index" onchange="f1(this.value);f11(this.value);f21(this.value);">

<option value="">Διάλεξε Γενικό δείκτη</option>

  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 5 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>
</div>
<br>
<br>

<div id="choice_1" name="choice_1" class="select">
 <select name="year" id="year">
<option value="">Διάλεξε Έτος Μεταβολής</option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f1(val)
{
	$.ajax({
	type: "POST", 
	url:"query20_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#year").html(data);
	}
});
}
</script>

</div>


<div id="choice_2" class="select">
 <select name="gender" id="gender" onchange="f12(this.value);">
 <option value="">Διάλεξε Φύλο Αλλοδαπών</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f11(val)
{
	$.ajax({
	type: "POST", 
	url:"query21_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#gender").html(data);
	}
});
}
</script>
<br>
<br>

 <select name="gender_1" id="gender_1" onchange="f13(this.value);">
 <option value="">Διάλεξε Φύλο</option>
</select>
<br>
<br>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f12(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query21_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#gender_1").html(data);
	}
});
}
</script>




 <select name="year_1" id="year_1" onchange = "f14(this.value);">
 <option value="">Διάλεξε Έτος</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f13(val)
{
	var val2 = $("#gender option:selected").val();
	var val1 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query21_3.php",
	data:{'g1': val, 'g':val2,'id':val1},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>

<br>
<br>
 <select name="tcn_country_prosfyges" id="tcn_country_prosfyges">
 <option value="">Διάλεξε Χώρα Αλλοδαπών</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f14(val)
{
	var val3 = $("#gender_1 option:selected").val();
	var val2 = $("#gender option:selected").val();
	var val1 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query21_4.php",
	data:{'year': val, 'g':val2,'id':val1,'g1':val3},
	success: function(data)
	{
			$("#tcn_country_prosfyges").html(data);
	}
});
}
</script>




<br>
<br>
</div>

<div id="choice_3" class="select">
 <select name="gender_2" id="gender_2" onchange="f22(this.value);">
 <option value="">Διάλεξε Φύλο</option>
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f21(val)
{
	$.ajax({
	type: "POST", 
	url:"query21_1.php",
	data:"id="+val,
	success: function(data)
	{
			$("#gender").html(data);
			$("#gender_2").html(data);
	}
});
}
</script>
<br>
<br>

 <select name="gender_3" id="gender_3" onchange="f23(this.value);">
 <option value="">Διάλεξε Φύλο</option>
  
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f22(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query21_2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#gender_3").html(data);
	}
});
}
</script>




<br>
<br>
 <select name="year_2" id="year_2">
 <option value="">Διάλεξε Έτος</option>
  
</select>
<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f23(val)
{
	var val2 = $("#gender_2 option:selected").val();
	var val1 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"query21_3.php",
	data:{'g1': val, 'g':val2,'id':val1},
	success: function(data)
	{
			$("#year_2").html(data);
	}
});
}
</script>
</div>


<br><br/>
<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>
<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";
$year= "";

$gender = "";
$gender_1 = "";
$year_1= "";
$tcn_country_prosfyges = "";

$gender_2 = "";
$gender_3 = "";
$year_2= "";
$table= "";

if (isset($_POST["submit"])){

	$category = $_POST['category'];
	$gen_index = $_POST['gen_index'];
	$year= $_POST['year'];
	
	$gender = $_POST['gender'];
	$gender_1 = $_POST['gender_1'];
	$year_1= $_POST['year_1'];
	$tcn_country_prosfyges = $_POST['tcn_country_prosfyges'];
	
	$gender_2 = $_POST['gender_2'];
	$gender_3= $_POST['gender_3'];
	$year_2= $_POST['year_2'];
	
	
	
	if ((empty($category) || empty($gen_index) ||  empty($year)) && (empty($category) || empty($gen_index) ||  empty($gender) || empty($gender_1)  || empty($tcn_country_prosfyges) || empty($year_1))  && (empty($category) || empty($gen_index) ||  empty($gender_2) || empty($gender_3)  || empty($year_2) ) )
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{
	

	
	if ($gen_index == 20)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data3, spec_index, year WHERE data3.year_id = year.id and data3.spec_index_id = spec_index.id   and data3.cat_id = $category and data3.gen_index_id = $gen_index  and data3.year_id = $year";
		
	}
	else if($gen_index == 21)
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data3, spec_index, year WHERE data3.year_id = year.id and data3.spec_index_id = spec_index.id   and data3.cat_id = $category and data3.gen_index_id = $gen_index and  data3.gender_id1 = $gender and data3.gender_id2 = $gender_1 and data3.year_id = $year_1 and data3.tcn_country_prosfyges_id = $tcn_country_prosfyges ";
		$sql2 = "SELECT tcn_country_name_prosfyges FROM tcn_country_prosfyges WHERE id = $tcn_country_prosfyges";
		$result2 = mysqli_query($db, $sql2);
		echo "Έχετε επιλέξει ως Όνομα χώρας:";
		while($row = mysqli_fetch_row($result2))
			{
				echo "<td>".$row[0]."</td>";
			}
			
	}
	
	else
	{
		$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data3, spec_index, year WHERE data3.year_id = year.id and data3.spec_index_id = spec_index.id   and data3.cat_id = $category and data3.gen_index_id = $gen_index and  data3.gender_id1 = $gender_2 and data3.gender_id2 = $gender_3 and data3.year_id = $year_2 ";
		
		
		$query1 = "SELECT  year.year_number as Έτος, gender.g_name as Φύλλο, calc Τιμή_Δείκτη FROM  data3, gender, year WHERE data3.year_id = year.id and data3.gender_id1 = gender.id   and data3.cat_id = $category and data3.gen_index_id = $gen_index and data3.gender_id2 = $gender_3 and data3.year_id = $year_2 ";
		$result1 = mysqli_query($db, $query1);
		
		$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Φύλλο', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (string) $r['Φύλλο']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format
$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);
}

		
		
	
		
		$result = mysqli_query($db, $query);
		if(! $result) {
		die("SQL Error: " . mysqli_error($db));
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
		{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
		}
	

	}
}
	


	
echo "</table>";


	
mysqli_close($db);	

//echo $jsonTable; 
?>

<!--Load the Ajax API-->

<br>
	 <br>
     <input type='button' class="button button1" value="Column Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
     <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	
	function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το φύλο',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
	   
    }
    </script>
     

 </div>


 <!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="display:none"></div>
	<div id="chart2div" style="display:none"></div>


 </div>
<p><?php echo $error_message; ?></p>	


</div>
</body>
</html>