/**
* File: js/showhide.js
* Purpose: toggle the visibility of fields depending on the value of another field
**/
$(document).ready(function() {
    toggleFields();	//call this first so we start out with the correct visibility depending on the selected form values
   //this will call our toggleFields function every time the selection value of our underAge field changes
    $("#middle").change(function() { toggleFields();	});

});
//this toggles the visibility of our parent permission fields depending on the current selected value of the underAge field
function toggleFields()
{
	
	if ($("#middle").val() == 1)
		
	{
		
		$("#choice_1").show()  ;
		
	}
        
    else
	{
		$("#choice_1").hide();
	}
        
	
	if ($("#middle").val() == 2)
	{
		$("#choice_2").show()  ;
	}
        
    else
	{
		$("#choice_2").hide();
	}
	
	if ($("#middle").val() == 3)
		
	{
		
		$("#choice_3").show()  ;
		
	}
        
    else
	{
		$("#choice_3").hide();
	}
	
	if ($("#middle").val() == 4)
		
	{
		
		$("#choice_4").show()  ;
		
	}
        
    else
	{
		$("#choice_4").hide();
	}
	
	
	if ($("#middle").val() == 5)
		
	{
		
		$("#choice_5").show()  ;
		
	}
        
    else
	{
		$("#choice_5").hide();
	}
        
	
}



