<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	//$query = "SELECT year_id,year_number FROM data2,year where gen_index_id = '".$id."' and year.id = data2.year_id";
	$query = "SELECT year_id,year_number FROM data3,year where year.id = data3.year_id and gen_index_id = $id";
	$result = mysqli_query($db, $query); 
	?>
	
		<option value="" selected>Διάλεξε Έτος Μεταβολής</option>

	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["year_id"]; ?>"><?php echo $nationality["year_number"] ?></option>
	<?php		
		
		
	}
}

?>