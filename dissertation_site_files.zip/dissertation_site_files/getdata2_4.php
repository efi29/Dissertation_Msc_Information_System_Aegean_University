<?php
include_once "connection.php";

	$query = "SELECT * FROM tcn_country where id>0";
	$result = mysqli_query($db, $query);
	?> 
	
	<option value="">Διάλεξε Κυρίαρχη χώρα</option>
	
	<?php
	foreach($result as $data2)
	{
	?>
		
		<option value="<?php echo $data2["id"]; ?>"><?php echo $data2["tcn_country_name"] ?></option>
	<?php		
		
		
	
}
?>