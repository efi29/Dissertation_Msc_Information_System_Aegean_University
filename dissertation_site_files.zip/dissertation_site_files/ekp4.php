<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$nat1 = $_POST["nat1"];
	$vath = $_POST["vath"];
	$query = "SELECT distinct apok_dioikisi_id,dioikisi_name FROM data12,apok_dioikisi where gen_index_id = $pid and vathmida_ekpaideysis_id = $vath and nat_id1 = $nat1 and nat_id2=$id and apok_dioikisi.id = data12.apok_dioikisi_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε αποκεντρωμένη διοίκηση</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["apok_dioikisi_id"]; ?>"><?php echo $nationality["dioikisi_name"] ?></option>
	<?php		
		
		
	}
}

?>