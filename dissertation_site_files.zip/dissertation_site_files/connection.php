<?php
$db = new mysqli('localhost','root','','datahandle');
if (mysqli_connect_errno())
 {
	echo 'Cannot connect to database: ' . mysqli_connect_errno();
 }
 else
 {
	mysqli_query($db,"SET NAMES 'utf8'");
	mysqli_query($db,"SET CHARACTER SET 'utf8'");
 }
 

?>