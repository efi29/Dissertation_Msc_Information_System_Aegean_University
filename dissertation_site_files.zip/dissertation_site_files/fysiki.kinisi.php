<?php
//γίνεται η σύνδεση με τη βάση
require_once "connection.php";

?>
<!DOCTYPE HTML>
 <html>
 <head>
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
 <title>ΔΕΙΚΤΕΣ ΦΥΣΙΚΗΣ ΚΙΝΗΣΗΣ</title>
 <script type="text/javascript" src="//code.jquery.com/jquery-1.12.0.min.js"></script>
 <link href="style.css" rel="stylesheet" type="text/css" media="screen" />

<style>
 <style>
 .container {
  display:none;
  
}
th {
	  height: 30px;
    height: 50px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
td {
	  height: 30px;
    height: 30px;
    vertical-align: bottom;
	text-shadow: 0 -1px 1px rgba(0,0,0,0.4);

}
 </style>
 </style>
 </head>
 <body>
<ul class="snip1189">
<li><a href="main.php">Αρχική Σελίδα</a></li>
<li><a href="Ekp_Enilikon.php">Εκπ.Ενηλίκων</a></li>
<li  ><a href="oaee.php">ΟΑΕΕ</a></li>
<li><a href="ithageneia.php">Ιθαγένεια</a></li>
<li><a href="prosfyges.php">Πρόσφυγες</a></li>
<li ><a href="gamoi.php">Γάμοι</a></li>
<li><a href="ygeia.php">Υγεία</a></li>
<li><a href="xenofovia.php">Ξενοφοβία</a></li>
<li><a href="eisodima.php">Εισόδημα</a></li>
<li><a href="met_kinisi.php">Μεταναστευτική Κίνηση</a></li>
<li><a href="loipa_dimografika.php">Λοιπά Δημογραφικά</a></li>
<li><a href="oaed_anergia.php">ΟΑΕΔ - Ανεργία</a></li>
<li><a href="ekp.palinostounton.php">Εκπαίδευση Παλιννοστούντων</a></li>
<li class="current"><a href="fysiki.kinisi.php">Φυσική Κίνηση</a></li>
<li><a href="astynomia_new.php">Αστυνομία</a></li>
<li><a href="adeies_paramonis.php">Άδειες Παραμονής</a></li>
<li><a href="katadikoi.php">Κατάδικοι</a></li>
<li><a href="apasxolisi_eisodima.php">Απασχόληση και Εισόδημα</a></li>
</ul>
 <h3>ΔΕΙΚΤΕΣ ΦΥΣΙΚΗΣ ΚΙΝΗΣΗΣ</h3>
 
 <!--"?" η εμφανιση των αποτελεσμάτων θα είναι στην ίδια σελίδα-->
 <form action="?" method="post">

<div class="select">
 <select name="category">
 <option value="">Διάλεξε κατηγορία</option>
  
 <?php
	
	$query = "SELECT * FROM category WHERE theme_id = 13";
	$result = mysqli_query($db, $query);
	
	foreach($result as $category)
	{
		?>
		<option value="<?php echo $category["id"]; ?>"><?php echo $category["cat_name"] ?></option>
	<?php	 
	}
?>
</select>
<br/><br/>

<select name="gen_index" id="gen_index" onchange="f1(this.value);">
<option value="">Διάλεξε Γενικό δείκτη</option>
  
	<?php
	
	$query = "SELECT * FROM gen_index WHERE category_id = 17 ";
	$result = mysqli_query($db, $query);
	
	foreach($result as $gen_index)
	{
		?>
		<option id="<?php echo $gen_index["id"];?>" value="<?php echo $gen_index["id"]; ?>"><?php echo $gen_index["index_name"] ?></option>
	<?php	 
	}

	?>
</select>

<br/><br/>


	 <select name="nationality_1" id="nationality_1" onchange="f2(this.value);">
 <option value="">Διάλεξε Εθνικότητα</option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f1(val)
{
	$.ajax({
	type: "POST", 
	url:"f1.php",
	data:{'id': val},
	success: function(data)
	{
			$("#nationality_1").html(data);
	}
});
}
</script>
	
<br/><br/>

 <select name="apok_dioikisi" id="apok_dioikisi" onchange="f3(this.value);">
 <option value="">Αποκεντρωμένη Διοίκηση</option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f2(val)
{
	var val2 = $("#gen_index option:selected").val();
	$.ajax({
	type: "POST", 
	url:"f2.php",
	data:{'id': val, 'pid':val2},
	success: function(data)
	{
			$("#apok_dioikisi").html(data);
	}
});
}
</script>

<br/><br/>

 <select name="perifereia" id="perifereia" onchange="f4(this.value);">
 <option value="">Περιφέρεια</option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f3(val)
{
	$.ajax({
	type: "POST", 
	url:"o4.php",
	data:{'id': val},
	success: function(data)
	{
			$("#perifereia").html(data);
	}
});
}
</script>
<br/><br/>

	<select name="year_1" id="year_1">
	<option value="">Διάλεξε Έτος  </option>
</select>

<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
<script>
function f4(val)
{
	var val2 = $("#gen_index option:selected").val();
	var val3 = $("#nationality_1 option:selected").val();
	var val4 = $("#apok_dioikisi option:selected").val();

	$.ajax({
	type: "POST", 
	url:"f4.php",
	data:{'id': val, 'pid':val2,'nat':val3,'apok':val4},
	success: function(data)
	{
			$("#year_1").html(data);
	}
});
}
</script>

<br/><br/>


<input type="submit" name="submit" id="submit" value="Υποβολή" >
</form>

<div>
<?php

$error_message = "";
$category = "";
$gen_index = "";
$nationality_1 = "";
$apok_dioikisi = "";
$perifereia = "";
$year_1= "";
$result1 = ""; 
$error_message = "";

if (isset($_POST["submit"])){

$category = $_POST['category'];
$gen_index = $_POST['gen_index'];
$nationality_1 = $_POST['nationality_1'];
$apok_dioikisi = $_POST['apok_dioikisi'];
$perifereia = 	$_POST['perifereia'];
$year_1 = $_POST['year_1'];



	if ((empty($category) || empty($gen_index)  || empty($nationality_1)  || empty($apok_dioikisi) || empty($perifereia) || empty($year_1) ) )
	{
		$error_message = "*Ένα ή περισσότερα πεδία δεν έχουν συμπληρωθεί";
	}else
	{

			$query = "SELECT  year.year_number as Year, spec_index.index_name as Name, calc  FROM  data13, spec_index, year WHERE data13.year_id = year.id and data13.spec_index_id = spec_index.id   and data13.cat_id = $category and data13.gen_index_id = $gen_index and data13.nat_id = $nationality_1  and data13.apok_dioikisi_id = $apok_dioikisi and data13.perifereia_id = $perifereia and data13.year_id = $year_1";
	
			$result = mysqli_query($db, $query);
			
			$query1 = "SELECT  year.year_number as Έτος, spec_index.index_name as Όνομα_Δείκτη, calc as Τιμή_Δείκτη FROM  data13, spec_index, year WHERE data13.year_id = year.id and data13.spec_index_id = spec_index.id   and data13.cat_id = $category and data13.gen_index_id = $gen_index and data13.nat_id = $nationality_1  and data13.apok_dioikisi_id = $apok_dioikisi and data13.perifereia_id = $perifereia";
			$result1 = mysqli_query($db, $query1);
			
			if($result === FALSE) { 
			die(mysql_error()); // TODO: better error handling
		}
		

		
		echo "<table border='1'>
			<tr>
			<th>Έτος</th>
			<th>Όνομα Δείκτη</th>
			<th>Τιμή Δείκτη</th>
			</tr>";

		while($row = mysqli_fetch_row($result))
			{
				
				echo "<tr>";
				echo "<td>".$row[0]."</td>";
				echo "<td>".$row[1]."</td>";
				echo "<td>".$row[2]."</td>";
				echo "</tr>";
			}
	


	

	
echo "</table>";

$rows = array();
	$table = array();
 
	$table['cols'] = array(

    // Labels for your chart, these represent the column titles.
    /* 
        note that one column is in "string" format and another one is in "number" format 
        as pie chart only required "numbers" for calculating percentage 
        and string will be used for Slice title
    */

    array('label' => 'Έτος', 'type' => 'string'),
    array('label' => 'Τιμή_Δείκτη', 'type' => 'number')

);
    /* Extract the information from $result */
	if($result1) {
    foreach($result1 as $r) {

      $temp = array();

      // The following line will be used to slice the Pie chart

      $temp[] = array('v' => (integer) $r['Έτος']);
	  

      // Values of the each slice

      $temp[] = array('v' => (float) $r['Τιμή_Δείκτη']); 
	   
      $rows[] = array('c' => $temp);
    }
	}
$table['rows'] = $rows;
	
// convert data into JSON format
$jsonTable = json_encode($table, JSON_UNESCAPED_UNICODE);

	}
}
	
mysqli_close($db);	

?>

<!--Load the Ajax API-->

<br/>
	<input type='button' class="button button1" value="Bar Chart" onclick='$("#chart_div").show();$("#chart2div").hide()'>
    <input type='button' class="button button1" value="Bar Chart" onclick='$("#chart2div").show();$("#chart_div").hide()'>
	
	
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script type="text/javascript">
	google.charts.load('current', {packages: ['corechart']});
	google.charts.setOnLoadCallback(drawChart);
	


    function drawChart() {

      // Create our data table out of JSON data loaded from server.
      var data = new google.visualization.DataTable(<?=$jsonTable?>);
	  var view = new google.visualization.DataView(data);
	  
      var options = {
          title: 'Γραφική απεικόνιση σε σχέση με το έτος',
          is3D: 'true',
		  colors: ['#bf00ff', '#bf00ff'],
          width: 1000,
          height: 600
        };
      // Instantiate and draw our chart, passing in some options.
      // Do not forget to check your div ID
      var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
	  
      chart.draw(data, options);
	  var chart = new google.visualization.BarChart(document.getElementById('chart2div'));
	  
      chart.draw(data, options);
    }
    </script>
 

</div>
	 <p><?php echo $error_message; ?></p>	
	<!--this is the div that will hold the pie chart-->
    <div id="chart_div" style="width: 1200px; height: 800px; display:none"></div>
	<div id="chart2div"  style="width: 900px; height: 500px; display:none"></div>			

</body>
</html>