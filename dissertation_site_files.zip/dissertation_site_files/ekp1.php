<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$query = "SELECT distinct vathmida_ekpaideysis_id,vathmida_ekpaideysis_name  FROM data12,vathmida_ekpaideysis where gen_index_id = $id and vathmida_ekpaideysis.id = data12.vathmida_ekpaideysis_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Βαθμίδα εκπαίδευσης</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["vathmida_ekpaideysis_id"]; ?>"><?php echo $nationality["vathmida_ekpaideysis_name"] ?></option>
	<?php		
		
		
	}
}

?>