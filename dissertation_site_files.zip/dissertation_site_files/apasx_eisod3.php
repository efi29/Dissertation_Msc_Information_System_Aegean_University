<?php
include_once "connection.php";


if(!empty($_POST["pid"]))
{
	$id = $_POST["pid"];
	$nat = $_POST["nat"];
	$gender = $_POST["gender"];
	$query = "SELECT distinct apok_dioikisi_id,dioikisi_name FROM data17,apok_dioikisi where gen_index_id = $id and nat_id = $nat and gender_id = $gender and apok_dioikisi.id = data17.apok_dioikisi_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Αποκεντρωμένη Διοίκηση</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["apok_dioikisi_id"]; ?>"><?php echo $nationality["dioikisi_name"] ?></option>
	<?php		
		
		
	}
}

?>