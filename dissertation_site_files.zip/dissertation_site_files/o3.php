<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	$pid = $_POST["pid"];
	$nat = $_POST["nat"];	
	$query = "SELECT distinct apok_dioikisi_id,dioikisi_name FROM data11,apok_dioikisi where nat_id2 = $id and nat_id1 = $nat and gen_index_id = $pid and apok_dioikisi.id = data11.apok_dioikisi_id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε αποκεντρωμένη διοίκηση</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["apok_dioikisi_id"]; ?>"><?php echo $nationality["dioikisi_name"] ?></option>
	<?php		
		
		
	}
}

?>