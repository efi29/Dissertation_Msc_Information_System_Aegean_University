<?php
include_once "connection.php";


if(!empty($_POST["pid"]))
{
	$id = $_POST["pid"];
	$nat = $_POST["nat"];
	$middle = $_POST["gender"];
	$query = "SELECT distinct gender_id,g_name FROM data7,gender where data7.gen_index_id = $id  and data7.middle_id = $middle and data7.nat_id = $nat and data7.gender_id = gender.id";
	$result = mysqli_query($db, $query); 
	?>
			<option value="" selected>Διάλεξε Φύλο</option>

	
	<?php
	foreach($result as $nationality)
	{
	?>
		
		<option value="<?php echo $nationality["gender_id"]; ?>"><?php echo $nationality["g_name"] ?></option>
	<?php		
		
		
	}
}

?>