<?php
include_once "connection.php";


if(!empty($_POST["id"]))
{
	$id = $_POST["id"];
	//τρεχουμε το ερωτημα : όπου βρουμε gen_index_id στον πίνακα spec_index για να εμφανισουμε index_name
	$query = "SELECT * FROM spec_index WHERE  gen_index_id= $id";
	$result = mysqli_query($db, $query);?>
	
	<option value="">Διάλεξε Φύλο</option>
	
	<?php
	foreach($result as $spec_index)
	{
	?>
		
		<option value="<?php echo $spec_index["id"]; ?>"><?php echo $spec_index["index_name"] ?></option>
	<?php		
		
		
	}
}

?>